import { createSelector } from 'reselect';
export var selectLegendSettings = state => state.legend.settings;
export var selectLegendSize = state => state.legend.size;
var selectAllLegendPayload2DArray = state => state.legend.payload;
export var selectLegendPayload = createSelector([selectAllLegendPayload2DArray], payloads => payloads.flat(1));